class Movie{
  int? id;
  String? name;
  String? subTitle;
  String? details;
  String? type;
  String? image;
  double? rating;

  Movie(
      {this.id,
      this.name,
      this.subTitle,
      this.details,
      this.type,
      this.image,
      this.rating});
}