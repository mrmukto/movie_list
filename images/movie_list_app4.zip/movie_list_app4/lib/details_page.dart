import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:movie_list_app4/models/models.dart';

class MovieDetails extends StatefulWidget {

  final Movie movie;

  MovieDetails(this.movie);

  @override
  State<MovieDetails> createState() => _MovieDetailsState();
}

class _MovieDetailsState extends State<MovieDetails> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text(widget.movie.name!),),

    );
  }
}
