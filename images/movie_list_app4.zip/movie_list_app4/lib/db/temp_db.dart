import 'package:movie_list_app4/models/models.dart';

final movieList=[
  Movie(id: 1,name: 'KGF',subTitle: 'good movie',details: 'Its a very good movie',type: 'Action',image: 'images/m1.PNG',rating: 4.3),
  Movie(id: 2,name: 'RRR',subTitle: 'good movie',details: 'Its a very good movie',type: 'Action',image: 'images/m2.PNG',rating: 2.3),
  Movie(id: 3,name: 'Pushpa',subTitle: 'good movie',details: 'Its a very good movie',type: 'Action',image: 'images/m3.PNG',rating: 3.3),
  Movie(id: 4,name: 'PK',subTitle: 'good movie',details: 'Its a very good movie',type: 'Action',image: 'images/m4.PNG',rating: 1.3),
  Movie(id: 5,name: 'Race',subTitle: 'good movie',details: 'Its a very good movie',type: 'Action',image: 'images/m5.PNG',rating: 4),
  Movie(id: 6,name: '3D',subTitle: 'good movie',details: 'Its a very good movie',type: 'Action',image: 'images/m6.PNG',rating: 5),
  Movie(id: 7,name: '300',subTitle: 'good movie',details: 'Its a very good movie',type: 'Action',image: 'images/m1.PNG',rating: 4),
  Movie(id: 8,name: 'KGF',subTitle: 'good movie',details: 'Its a very good movie',type: 'Action',image: 'images/m1.PNG',rating: 4.3),
  Movie(id: 9,name: 'KGF',subTitle: 'good movie',details: 'Its a very good movie',type: 'Action',image: 'images/m1.PNG',rating: 4.3),
  Movie(id: 10,name: 'KGF',subTitle: 'good movie',details: 'Its a very good movie',type: 'Action',image: 'images/m1.PNG',rating: 4.3),
  Movie(id: 11,name: 'KGF',subTitle: 'good movie',details: 'Its a very good movie',type: 'Action',image: 'images/m1.PNG',rating: 4.3),
  Movie(id: 12,name: 'KGF',subTitle: 'good movie',details: 'Its a very good movie',type: 'Action',image: 'images/m2.PNG',rating: 4.3),
  Movie(id: 13,name: 'Ra One',subTitle: 'good movie',details: 'Its a very good movie',type: 'Action',image: 'images/m3.PNG',rating: 1.3),
  Movie(id: 14,name: 'Dhoom',subTitle: 'good movie',details: 'Its a very good movie',type: 'Action',image: 'images/m4.PNG',rating: 2.3),
  Movie(id: 15,name: 'Dhoom 2',subTitle: 'good movie',details: 'Its a very good movie',type: 'Action',image: 'images/m5.PNG',rating: 3.3),
];