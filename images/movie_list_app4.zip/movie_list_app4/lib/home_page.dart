import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:movie_list_app4/db/temp_db.dart';
import 'package:movie_list_app4/details_page.dart';

class HomePage extends StatefulWidget {

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Movie List'),),
      body: ListView.builder(
        itemCount: movieList.length,
        itemBuilder: (context,index)=>Padding(
          padding: const EdgeInsets.all(8.0),
          child: ListTile(
            tileColor: Colors.grey,
            onTap: (){
              Navigator.push(context, MaterialPageRoute
                (builder: (context)=>MovieDetails(movieList[index])));
            },
            title: Text(movieList[index].name!),
            subtitle: Text(movieList[index].subTitle!),
            leading: Image.asset(movieList[index].image!,width: 40,),
            trailing: Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                Text(movieList[index].rating!.toString()),
                Icon(Icons.star,color: index.isEven?Colors.green:Colors.red,)
              ],
            ),
          ),
        ))
      );
  }
}

class MyListView extends StatelessWidget {
  const MyListView({
    Key? key,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return ListView(
    children: movieList.map((movie) => Padding(
      padding: const EdgeInsets.all(8.0),
      child: ListTile(
        tileColor: Colors.grey,
        onTap: (){
          Navigator.push(context, MaterialPageRoute
            (builder: (context)=>MovieDetails(movie)));
        },
        title: Text(movie.name!),
        subtitle: Text(movie.subTitle!),
        leading: Image.asset(movie.image!,width: 40,),
        trailing: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            Text(movie.rating!.toString()),
            Icon(Icons.star)
          ],
        ),
      ),
    )).toList(),
    );
  }
}
