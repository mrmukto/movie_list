package com.example.movie_list_app4

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
